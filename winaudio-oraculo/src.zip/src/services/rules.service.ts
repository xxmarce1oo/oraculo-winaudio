import { createSupabaseBrowserClient } from '@/lib/supabase-browser';
import type { Rule, RuleFormData } from '@/types';

export const rulesService = {
  async getAll(): Promise<{ data: Rule[]; error: string | null }> {
    try {
      const supabase = createSupabaseBrowserClient();
      const { data, error } = await supabase
        .from('rules')
        .select(`
          id, 
          title, 
          content,
          type, 
          department_id, 
          created_at,
          departments ( id, name )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Erro ao buscar normas:', error);
        return { data: [], error: 'Erro ao buscar normas' };
      }

      return { data: (data as Rule[]) || [], error: null };
    } catch (error) {
      console.error('Erro inesperado:', error);
      return { data: [], error: 'Erro inesperado ao buscar normas' };
    }
  },

  async getById(id: string): Promise<{ data: Rule | null; error: string | null }> {
    try {
      const supabase = createSupabaseBrowserClient();
      const { data, error } = await supabase
        .from('rules')
        .select(`
          id, 
          title, 
          content,
          type, 
          department_id, 
          created_at,
          departments ( id, name )
        `)
        .eq('id', id)
        .single();

      if (error) {
        console.error('Erro ao buscar norma:', error);
        return { data: null, error: 'Erro ao buscar norma' };
      }

      return { data: data as Rule, error: null };
    } catch (error) {
      console.error('Erro inesperado:', error);
      return { data: null, error: 'Erro inesperado ao buscar norma' };
    }
  },

  async create(ruleData: RuleFormData): Promise<{ success: boolean; error: string | null }> {
    try {
      const supabase = createSupabaseBrowserClient();
      const { error } = await supabase.from('rules').insert([ruleData]);

      if (error) {
        console.error('Erro ao salvar:', error);
        return { success: false, error: 'Erro ao salvar a normativa' };
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Erro inesperado:', error);
      return { success: false, error: 'Erro inesperado ao salvar' };
    }
  },

  async update(id: string, ruleData: Partial<RuleFormData>): Promise<{ success: boolean; error: string | null }> {
    try {
      const supabase = createSupabaseBrowserClient();
      const { error } = await supabase
        .from('rules')
        .update(ruleData)
        .eq('id', id);

      if (error) {
        console.error('Erro ao atualizar:', error);
        return { success: false, error: 'Erro ao atualizar a normativa' };
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Erro inesperado:', error);
      return { success: false, error: 'Erro inesperado ao atualizar' };
    }
  },

  async delete(id: string): Promise<{ success: boolean; error: string | null }> {
    try {
      const supabase = createSupabaseBrowserClient();
      const { error } = await supabase.from('rules').delete().eq('id', id);

      if (error) {
        console.error('Erro ao excluir:', error);
        return { success: false, error: 'Não foi possível excluir a normativa' };
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Erro inesperado:', error);
      return { success: false, error: 'Erro inesperado ao excluir' };
    }
  },
};
